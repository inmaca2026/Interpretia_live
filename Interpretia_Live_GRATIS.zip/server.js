const express = require('express');
const path = require('path');
const app = express();
app.use(express.json({limit:'100kb'}));
app.use(express.static(path.join(__dirname,'public')));
const PORT=process.env.PORT||3000;
app.get('/health',(_req,res)=>res.json({ok:true,service:'Interpretia Live Free'}));
app.post('/api/translate',async(req,res)=>{
  const text=typeof req.body?.text==='string'?req.body.text.trim():'';
  const target=req.body?.target==='es'?'es':'en';
  if(!text)return res.status(400).json({error:'Texto vacío.'});
  if(text.length>1800)return res.status(400).json({error:'Fragmento demasiado largo.'});
  try{
    // MyMemory offers an unauthenticated free translation endpoint for light usage.
    const langpair=target==='es'?'en|es':'es|en';
    const url='https://api.mymemory.translated.net/get?q='+encodeURIComponent(text)+'&langpair='+langpair;
    const r=await fetch(url,{headers:{'User-Agent':'Interpretia-Live-Free/1.0'}});
    const data=await r.json();
    if(!r.ok) return res.status(r.status).json({error:'El servicio gratuito de traducción no respondió.'});
    const translation=data?.responseData?.translatedText;
    if(!translation) return res.status(502).json({error:'No se obtuvo traducción.'});
    res.json({translation,provider:'MyMemory'});
  }catch(e){res.status(502).json({error:'No fue posible conectar con el traductor gratuito.'});}
});
app.get('*',(req,res)=>{if(req.path.startsWith('/api/'))return res.status(404).end();res.sendFile(path.join(__dirname,'public','index.html'));});
app.listen(PORT,()=>console.log(`Interpretia Live Free running on port ${PORT}`));
