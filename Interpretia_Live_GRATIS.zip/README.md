# Interpretia Live — versión gratuita

Aplicación web/PWA para interpretación español ↔ inglés usando el reconocimiento de voz disponible en el navegador y un servicio de traducción web gratuito para uso ligero. Incluye el glosario consolidado y detección de términos/datos importantes.

## Sin API Key
Esta versión no usa OpenAI API ni requiere tarjeta. Render puede alojar el servidor en su plan gratuito. La traducción usa MyMemory sin autenticación para uso ligero; sus límites y disponibilidad dependen del proveedor.

## Instalación
1. Sube el proyecto a un repositorio privado de GitHub.
2. En Render crea un Web Service conectado al repositorio.
3. Build Command: `npm install`.
4. Start Command: `npm start`.
5. Plan: Free.
6. No agregues variables de entorno ni API keys.
7. Abre la URL HTTPS de Render en el teléfono/tablet y permite el micrófono.

## Audio
El botón Escuchar usa el micrófono del dispositivo. Una fuente de audio externa puede reproducirse cerca del micrófono o conectarse mediante una interfaz compatible. La captura interna de llamadas celulares no forma parte de esta versión.

## Nota de calidad
Al no usar un modelo premium, la calidad y los límites de traducción pueden ser inferiores a la versión con OpenAI. El glosario local se mantiene y sirve para identificar términos técnicos, pero no sustituye la traducción contextual.
