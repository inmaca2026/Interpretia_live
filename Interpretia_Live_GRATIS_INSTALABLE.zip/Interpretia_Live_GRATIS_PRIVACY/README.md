# Interpretia Live GRATIS — instalación multiplataforma

Versión gratuita de Interpretia Live con botón **📲 Instalar Interpretia**.

## Instalación
- Android/Chrome y navegadores Chromium compatibles: el botón puede abrir el instalador del navegador.
- iPhone/iPad: el botón muestra los pasos de Safari para **Compartir → Añadir a pantalla de inicio**.
- PC/Mac: en Chrome/Edge compatibles, el botón usa el instalador del navegador; si no está disponible, muestra la opción que debe buscarse en el menú del navegador.

La aplicación incluye manifest, service worker e iconos PWA para permitir la instalación cuando el navegador/OS lo admite.

## Ejecución
`npm install`
`npm start`

No requiere API Key de OpenAI.
